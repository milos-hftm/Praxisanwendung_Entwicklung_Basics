package ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Teilnahme;

@Repository
public interface TeilnahmeRepository extends JpaRepository<Teilnahme, Long> {
    boolean existsByMitgliedIdAndTerminId(Long mitgliedId, Long terminId);
}
