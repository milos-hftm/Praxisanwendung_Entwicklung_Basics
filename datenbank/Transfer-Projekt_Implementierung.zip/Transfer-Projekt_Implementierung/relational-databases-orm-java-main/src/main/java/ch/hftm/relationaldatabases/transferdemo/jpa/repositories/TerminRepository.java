package ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Termin;

@Repository
public interface TerminRepository extends JpaRepository<Termin, Long> {
    List<Termin> findAllByDatumGreaterThanEqualOrderByDatumAsc(LocalDate abDatum);
}
