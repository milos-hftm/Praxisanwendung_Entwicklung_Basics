-- Beispiel-Teilnahme für Mitglied (ID=1) bei Termin (ID=1)
-- Prüft vorher, ob noch keine Teilnahme für diese Kombination existiert
INSERT INTO teilnahme (mitglied_id, termin_id, status)
SELECT 1, 1, 'ZUGESAGT'
WHERE NOT EXISTS (
    SELECT 1 FROM teilnahme WHERE mitglied_id = 1 AND termin_id = 1
);
