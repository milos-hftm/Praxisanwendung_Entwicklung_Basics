package ch.hftm.relationaldatabases.transferdemo.web;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Globaler Exception-Handler:
 * - Gibt bei Business-Konflikten 409 (Conflict) statt 500 (Internal Server Error) zurueck.
 * - Deckt sowohl manuell geworfene IllegalStateException (z. B. doppelte Zusage)
 *   als auch DB-seitige Constraint-Verletzungen (Unique, FK) ab.
 */
@RestControllerAdvice
public class ApiExceptionHandler {

  /**
   * Business-Logik-Konflikte (z. B. "Teilnahme existiert bereits").
   */
  @ExceptionHandler(IllegalStateException.class)
  public ResponseEntity<String> handleIllegalState(IllegalStateException ex) {
    return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
  }

  /**
   * Datenbank-Constraint-Verletzungen (z. B. UNIQUE, FK).
   * Je nach Treiber/DB kann die Wurzelursache variieren; 409 ist hier semantisch korrekt.
   */
  @ExceptionHandler(DataIntegrityViolationException.class)
  public ResponseEntity<String> handleDataIntegrity(DataIntegrityViolationException ex) {
    String msg = "Datenkonflikt: Bitte Eingaben pruefen (evtl. bereits vorhanden oder unzulaessig).";
    return ResponseEntity.status(HttpStatus.CONFLICT).body(msg);
  }
}
