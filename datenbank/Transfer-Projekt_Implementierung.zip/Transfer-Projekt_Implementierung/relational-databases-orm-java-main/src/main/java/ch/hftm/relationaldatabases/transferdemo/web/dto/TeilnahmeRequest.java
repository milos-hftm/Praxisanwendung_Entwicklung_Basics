package ch.hftm.relationaldatabases.transferdemo.kud.web.dto;

import jakarta.validation.constraints.NotNull;

/**
 * Request-DTO fuer eine Teilnahme-Aktion (z. B. Zusage).
 * - mitgliedId ist Pflicht.
 * - formularId ist optional (kann null sein, wenn noch kein Formular zugeordnet ist).
 */
public record TeilnahmeRequest(
        @NotNull Long mitgliedId,
        Long formularId
) {}
