-- Beispiel-Mitglied
INSERT INTO mitglied (vorname, nachname, email, rolle)
VALUES ('Milos', 'Test', 'milos@test.ch', 'MITGLIED')
ON CONFLICT (email) DO NOTHING;

-- Beispiel-Termin
INSERT INTO termin (datum, uhrzeit, ort, ferien_flag)
VALUES ('2025-09-20', '19:00:00', 'Turnhalle Bern', false)
ON CONFLICT DO NOTHING;

-- Beispiel-Formular
INSERT INTO formular (typ, ausgabedatum, rueckgabedatum, status, mitglied_id)
VALUES ('Anmeldung', '2025-09-01', null, 'AUSSTEHEND', 1)
ON CONFLICT DO NOTHING;
