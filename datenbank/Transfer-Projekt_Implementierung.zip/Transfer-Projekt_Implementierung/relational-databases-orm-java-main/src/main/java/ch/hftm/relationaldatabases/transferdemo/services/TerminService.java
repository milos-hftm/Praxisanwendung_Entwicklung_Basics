package ch.hftm.relationaldatabases.transferdemo.kud.services;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import ch.hftm.relationaldatabases.transferdemo.kud.domain.TeilnahmeStatus;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Formular;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Mitglied;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Teilnahme;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Termin;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories.FormularRepository;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories.MitgliedRepository;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories.TeilnahmeRepository;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories.TerminRepository;
import jakarta.transaction.Transactional;

@Service
public class TerminService {

    private final TerminRepository terminRepo;
    private final MitgliedRepository mitgliedRepo;
    private final FormularRepository formularRepo;
    private final TeilnahmeRepository teilnahmeRepo;

    public TerminService(
            TerminRepository t,
            MitgliedRepository m,
            FormularRepository f,
            TeilnahmeRepository p
    ) {
        this.terminRepo = t;
        this.mitgliedRepo = m;
        this.formularRepo = f;
        this.teilnahmeRepo = p;
    }

    public List<Termin> listUpcoming() {
        return terminRepo.findAllByDatumGreaterThanEqualOrderByDatumAsc(LocalDate.now());
    }

    public Termin createTermin(Termin t) {
        return terminRepo.save(t);
    }

    @Transactional
    public Teilnahme zusagen(Long terminId, Long mitgliedId, Optional<Long> formularIdOpt) {
        if (teilnahmeRepo.existsByMitgliedIdAndTerminId(mitgliedId, terminId)) {
            throw new IllegalStateException("Teilnahme existiert bereits für dieses Mitglied und diesen Termin");
        }

        Termin termin = terminRepo.findById(terminId).orElseThrow();
        Mitglied mitglied = mitgliedRepo.findById(mitgliedId).orElseThrow();

        Teilnahme teilnahme = Teilnahme.builder()
                .termin(termin)
                .mitglied(mitglied)
                .status(TeilnahmeStatus.ZUGESAGT)
                .build();

        formularIdOpt.ifPresent(fid -> {
            Formular f = formularRepo.findById(fid).orElseThrow();
            teilnahme.setFormular(f);
        });

        return teilnahmeRepo.save(teilnahme);
    }

    @Transactional
    public Teilnahme absagen(Long teilnahmeId) {
        Teilnahme t = teilnahmeRepo.findById(teilnahmeId).orElseThrow();
        t.setStatus(TeilnahmeStatus.ABGESAGT);
        return teilnahmeRepo.save(t);
    }
}
