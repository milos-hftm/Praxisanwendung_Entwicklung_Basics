package ch.hftm.relationaldatabases.transferdemo.kud.domain;

public enum FormularStatus {
    AUSSTEHEND,
    EINGEREICHT,
    GEPRUEFT
}
