package ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "termin")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Termin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "termin_id")
    private Long id;

    @NotNull
    private LocalDate datum;

    @NotNull
    private LocalTime uhrzeit;

    @NotBlank @Size(max = 100)
    private String ort;

    @Builder.Default
    @Column(name = "ferien_flag", nullable = false)
    private boolean ferienFlag = false;
}
