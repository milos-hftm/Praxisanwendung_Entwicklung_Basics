package ch.hftm.relationaldatabases.transferdemo.kud.web;

import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Termin;
import ch.hftm.relationaldatabases.transferdemo.kud.services.TerminService;
import ch.hftm.relationaldatabases.transferdemo.kud.web.dto.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/termine")
public class TerminController {

    private final TerminService service;

    public TerminController(TerminService s) {
        this.service = s;
    }

    @GetMapping("/upcoming")
    public List<TerminDto> upcoming() {
        return service.listUpcoming().stream()
                .map(t -> new TerminDto(t.getId(), t.getDatum(), t.getUhrzeit(), t.getOrt(), t.isFerienFlag()))
                .toList();
    }

    @PostMapping
    public ResponseEntity<TerminDto> create(@RequestBody @Valid CreateTerminRequest req) {
        Termin t = Termin.builder()
                .datum(req.datum())
                .uhrzeit(req.uhrzeit())
                .ort(req.ort())
                .ferienFlag(req.ferienFlag())
                .build();
        Termin saved = service.createTermin(t);
        TerminDto dto = new TerminDto(saved.getId(), saved.getDatum(), saved.getUhrzeit(), saved.getOrt(), saved.isFerienFlag());
        return ResponseEntity.created(URI.create("/api/termine/" + saved.getId())).body(dto);
    }

    @PostMapping("/{terminId}/zusagen")
    public ResponseEntity<Long> zusagen(@PathVariable Long terminId, @RequestBody @Valid TeilnahmeRequest body) {
        var teilnahme = service.zusagen(terminId, body.mitgliedId(), Optional.ofNullable(body.formularId()));
        return ResponseEntity.ok(teilnahme.getId());
    }
}
