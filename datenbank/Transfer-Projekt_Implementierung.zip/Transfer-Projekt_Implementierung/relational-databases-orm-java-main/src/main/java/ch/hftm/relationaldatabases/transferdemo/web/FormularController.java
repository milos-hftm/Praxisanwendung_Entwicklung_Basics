package ch.hftm.relationaldatabases.transferdemo.kud.web;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.hftm.relationaldatabases.transferdemo.kud.domain.FormularStatus;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Formular;
import ch.hftm.relationaldatabases.transferdemo.kud.services.FormularService;

@RestController
@RequestMapping("/api/formulare")
public class FormularController {

    private final FormularService service;

    public FormularController(FormularService s) {
        this.service = s;
    }

    @PostMapping
    public ResponseEntity<Long> create(@RequestBody Formular f) {
        return ResponseEntity.ok(service.create(f).getId());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Void> setStatus(@PathVariable Long id, @RequestParam FormularStatus status) {
        service.setStatus(id, status);
        return ResponseEntity.noContent().build();
    }
}
