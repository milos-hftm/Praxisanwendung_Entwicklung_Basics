package ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Mitglied;

@Repository
public interface MitgliedRepository extends JpaRepository<Mitglied, Long> {
    Optional<Mitglied> findByEmail(String email);
}
