-- Ziel:
-- - FKs auf "teilnahme" mit sinnvollen ON DELETE-Regeln neu setzen
--   * mitglied_id  -> ON DELETE CASCADE
--   * termin_id    -> ON DELETE CASCADE
--   * formular_id  -> ON DELETE SET NULL
--
-- Hinweise:
-- - Das DO-Block-Droppen ist robust, weil es alle bestehenden FKs auf "teilnahme"
--   entfernt, egal wie sie heissen, und danach legen wir genau die drei benoetigten
--   FKs mit festen Namen wieder an.
-- - Flyway fuehrt diese Migration in einer Transaktion aus (PostgreSQL).

-- 1) Alle bestehenden FOREIGN KEYS auf "teilnahme" loeschen (namenunabhaengig)
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'teilnahme'::regclass
      AND contype = 'f'
  LOOP
    EXECUTE format('ALTER TABLE teilnahme DROP CONSTRAINT %I', r.conname);
  END LOOP;
END $$;

-- 2) FOREIGN KEYS mit klaren Regeln neu anlegen
ALTER TABLE teilnahme
  ADD CONSTRAINT fk_teilnahme_mitglied
    FOREIGN KEY (mitglied_id) REFERENCES mitglied(mitglied_id)
    ON DELETE CASCADE
    ON UPDATE NO ACTION;

ALTER TABLE teilnahme
  ADD CONSTRAINT fk_teilnahme_termin
    FOREIGN KEY (termin_id) REFERENCES termin(termin_id)
    ON DELETE CASCADE
    ON UPDATE NO ACTION;

ALTER TABLE teilnahme
  ADD CONSTRAINT fk_teilnahme_formular
    FOREIGN KEY (formular_id) REFERENCES formular(formular_id)
    ON DELETE SET NULL
    ON UPDATE NO ACTION;

