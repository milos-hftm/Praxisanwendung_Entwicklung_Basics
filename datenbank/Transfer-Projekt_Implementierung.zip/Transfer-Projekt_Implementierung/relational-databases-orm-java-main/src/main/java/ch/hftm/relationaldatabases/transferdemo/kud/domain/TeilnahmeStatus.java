package ch.hftm.relationaldatabases.transferdemo.kud.domain;

public enum TeilnahmeStatus {
    ZUGESAGT,
    ABGESAGT,
    ABWESEND
}
