package ch.hftm.relationaldatabases.transferdemo.kud.web.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public record TerminDto(
        Long id,
        LocalDate datum,
        LocalTime uhrzeit,
        String ort,
        boolean ferienFlag
) {}
