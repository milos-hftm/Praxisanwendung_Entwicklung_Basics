package ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities;

import ch.hftm.relationaldatabases.transferdemo.kud.domain.Rolle;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "mitglied", uniqueConstraints = {
    @UniqueConstraint(name = "uq_mitglied_email", columnNames = "email")
})
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Mitglied {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mitglied_id")
    private Long id;

    @NotBlank @Size(max = 50)
    private String vorname;

    @NotBlank @Size(max = 50)
    private String nachname;

    @NotBlank @Email @Size(max = 100)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Rolle rolle;
}
