package ch.hftm.relationaldatabases.transferdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransferdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransferdemoApplication.class, args);
	}

}
