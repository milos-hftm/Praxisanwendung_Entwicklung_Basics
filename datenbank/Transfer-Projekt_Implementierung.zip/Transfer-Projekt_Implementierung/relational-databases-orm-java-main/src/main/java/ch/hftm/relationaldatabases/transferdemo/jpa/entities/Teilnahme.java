package ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities;

import ch.hftm.relationaldatabases.transferdemo.kud.domain.TeilnahmeStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "teilnahme", uniqueConstraints = {
    @UniqueConstraint(name = "uq_teilnahme_mitglied_termin", columnNames = {"mitglied_id","termin_id"})
})
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Teilnahme {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "teilnahme_id")
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "mitglied_id", nullable = false)
    private Mitglied mitglied;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "termin_id", nullable = false)
    private Termin termin;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "formular_id", unique = true)
    private Formular formular;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TeilnahmeStatus status;
}
