package ch.hftm.relationaldatabases.transferdemo.kud.services;

import org.springframework.stereotype.Service;

import ch.hftm.relationaldatabases.transferdemo.kud.domain.FormularStatus;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities.Formular;
import ch.hftm.relationaldatabases.transferdemo.kud.jpa.repositories.FormularRepository;

@Service
public class FormularService {

    private final FormularRepository formularRepo;

    public FormularService(FormularRepository repo) {
        this.formularRepo = repo;
    }

    public Formular create(Formular f) {
        return formularRepo.save(f);
    }

    public Formular setStatus(Long id, FormularStatus status) {
        Formular f = formularRepo.findById(id).orElseThrow();
        f.setStatus(status);
        return formularRepo.save(f);
    }
}
