package ch.hftm.relationaldatabases.transferdemo.kud.jpa.entities;

import ch.hftm.relationaldatabases.transferdemo.kud.domain.FormularStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.*;

@Entity
@Table(name = "formular")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Formular {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "formular_id")
    private Long id;

    @NotBlank @Size(max = 50)
    private String typ;

    @NotNull
    private LocalDate ausgabedatum;

    private LocalDate rueckgabedatum;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FormularStatus status;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "mitglied_id", nullable = false)
    private Mitglied mitglied;
}
