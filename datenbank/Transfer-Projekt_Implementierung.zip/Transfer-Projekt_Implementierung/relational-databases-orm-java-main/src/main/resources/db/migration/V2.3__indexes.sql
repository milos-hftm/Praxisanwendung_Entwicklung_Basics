-- Indizes fuer typische Abfragen und Joins

-- fuer /api/termine/upcoming (Datum >= heute)
CREATE INDEX IF NOT EXISTS idx_termin_datum
  ON termin(datum);

-- schnellere Joins/Abfragen auf Teilnahmen pro Termin/Mitglied
CREATE INDEX IF NOT EXISTS idx_teilnahme_termin
  ON teilnahme(termin_id);

CREATE INDEX IF NOT EXISTS idx_teilnahme_mitglied
  ON teilnahme(mitglied_id);

-- optional sinnvoll: Formulare eines Mitglieds
CREATE INDEX IF NOT EXISTS idx_formular_mitglied
  ON formular(mitglied_id);
