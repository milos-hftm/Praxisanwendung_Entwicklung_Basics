package ch.hftm.relationaldatabases.transferdemo.web.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
// Optional, falls du verhindern willst, dass Termine in der Vergangenheit angelegt werden:
// import jakarta.validation.constraints.FutureOrPresent;

/**
 * Request-DTO zum Anlegen eines Termins.
 * Validierung stellt sicher, dass Pflichtfelder korrekt gefuellt sind.
 */
public record CreateTerminRequest(
        @NotNull /* @FutureOrPresent */ LocalDate datum,
        @NotNull LocalTime uhrzeit,
        @NotBlank @Size(max = 100) String ort,
        boolean ferienFlag
) {}
