# Projektarbeit – Termin- & Formularverwaltung (KUD Karadjordje Bern)

Digitale Verwaltung von **Terminen**, **Teilnahmen** und **Formularen** für den Tanzverein *KUD Karadjordje Bern*.  
Backend: **Spring Boot 3**, **Java 21**, **JPA/Hibernate**, **PostgreSQL 17**, **Flyway**, **Docker Compose**.

> **Quickstart**
> 1) DB starten:  
>    ```bash
>    docker compose -f docker-compose.db.yaml up -d
>    ```
> 2) App starten (Windows PowerShell):  
>    ```powershell
>    $env:JDBC_URL="jdbc:postgresql://localhost:5432/transferdemo"
>    $env:JDBC_USERNAME="transferdemo"
>    $env:JDBC_PASSWORD="transferdemo"
>    .\mvnw.cmd spring-boot:run -Dspring-boot.run.profiles=local
>    ```
> 3) Termin anlegen (Windows PowerShell):  
>    ```powershell
>    Invoke-RestMethod -Method POST http://localhost:8080/api/termine `
>      -ContentType "application/json" `
>      -Body '{ "datum": "2025-09-15", "uhrzeit": "19:00:00", "ort": "Turnhalle Bern", "ferienFlag": false }'
>    ```
>
> **macOS/Linux (Bash) Startbefehl:**
> ```bash
> export JDBC_URL="jdbc:postgresql://localhost:5432/transferdemo"
> export JDBC_USERNAME="transferdemo"
> export JDBC_PASSWORD="transferdemo"
> ./mvnw spring-boot:run -Dspring-boot.run.profiles=local
> ```

---
## 📸 Screenshots

### 1. App-Start
Zeigt den erfolgreichen Start von Spring Boot mit Flyway-Migrationen und Tomcat.  
![App Start](screenshots/01_app_start.png)

### 2. Datenbank-Tabellen & Flyway-Historie
Alle Tabellen (`mitglied`, `termin`, `formular`, `teilnahme`) und Migrationen (`2.1 seed`, `2.2 seed teilnahme`) sind vorhanden.  
![DB Tabellen](screenshots/02_db_tables.png)

### 3. API – Bevorstehende Termine
Abruf der kommenden Termine über `GET /api/termine/upcoming`.  
![API Upcoming](screenshots/03_api_upcoming.png)

### 4. API – Termin anlegen
Anlegen eines neuen Termins über `POST /api/termine`.  
![API Create Termin](screenshots/04_api_create_termin.png)

### 5. API – Teilnahme zusagen
Mitglied 1 sagt für Termin 3 zu via `POST /api/termine/{id}/zusagen`.  
![API Zusagen](screenshots/05_api_zusagen.png)

### 6. API – Formularstatus ändern
Änderung des Formularstatus auf `GEPRUEFT` via `PUT /api/formulare/{id}/status`.  
![API Formular Status](screenshots/06_api_formular_status.png)

---

## Inhalte

- [Ziele & Features](#ziele--features)  
- [Technologie-Stack](#technologie-stack)  
- [Datenmodell](#datenmodell)  
- [Projektstruktur](#projektstruktur)  
- [Setup & Start](#setup--start)  
- [Konfiguration](#konfiguration)  
- [Datenbankmigrationen (Flyway)](#datenbankmigrationen-flyway)  
- [REST API](#rest-api)  
- [Testing (PowerShell, Bash, Postman)](#testing-powershell-bash-postman)  
- [Troubleshooting](#troubleshooting)  
- [Roadmap](#roadmap)  
- [Lizenz & Dank](#lizenz--dank)

---

## Ziele & Features

- **Termine**: Anlegen, Auflisten kommender Termine, Ferien-Flag.
- **Mitglieder**: Basisverwaltung mit Rollen (**MITGLIED**, **TRAINER**, **ADMIN**).
- **Teilnahmen**: Zusagen/Absagen zu Terminen. **Regel**: pro Termin und Mitglied **genau eine** Teilnahme.
- **Formulare**: Erfassung mit Status (**AUSSTEHEND**, **EINGEREICHT**, **GEPRUEFT**) und optionaler Verknüpfung zur Teilnahme.
- **Persistenz**: Spring Data JPA auf PostgreSQL.
- **Migrationen**: Flyway (Schema + Seed-Daten).
- **Containerisierte DB**: Docker Compose.

---

## Technologie-Stack

- **Backend**: Spring Boot 3.4.x, Java 21, Spring Data JPA, Hibernate  
- **DB**: PostgreSQL 17 (Docker), Flyway  
- **Build**: Maven (Wrapper enthalten)  
- **Dev**: VS Code / IntelliJ, Lombok

---

## Datenmodell

**Tabellen**
- `mitglied(mitglied_id, vorname, nachname, email UNIQUE, rolle)`
- `termin(termin_id, datum, uhrzeit, ort, ferien_flag)`
- `formular(formular_id, typ, ausgabedatum, rueckgabedatum, status, mitglied_id → mitglied)`
- `teilnahme(teilnahme_id, mitglied_id → mitglied, termin_id → termin, formular_id → formular, status)`

**Wichtige Constraints**
- `UNIQUE (mitglied_id, termin_id)` in `teilnahme` (pro Mitglied nur eine Teilnahme pro Termin).
- `formular_id` in `teilnahme` ist **1:1** (ein Formular kann nur einer Teilnahme zugeordnet sein).
- Rollen & Status als `TEXT` mit CHECK-Constraints, in JPA als `EnumType.STRING`.

---

## Projektstruktur

```
src/main/java/ch/hftm/relationaldatabases/transferdemo/kud/
├── domain/                # Enums: Rolle, FormularStatus, TeilnahmeStatus
├── jpa/
│   ├── entities/          # Mitglied, Termin, Formular, Teilnahme
│   └── repositories/      # MitgliedRepository, TerminRepository, FormularRepository, TeilnahmeRepository
├── services/              # TerminService, FormularService
└── web/
    ├── dto/               # TerminDto, CreateTerminRequest, TeilnahmeRequest
    ├── controllers/       # TerminController, FormularController, TeilnahmeController
    └── ApiExceptionHandler.java
```

---

## Setup & Start

### Voraussetzungen
- Java 21
- Maven (oder Maven Wrapper `mvnw`)
- Docker Desktop (inkl. Docker Compose)

### 1) Datenbank starten (Docker)

**Alle OS:**
```bash
docker compose -f docker-compose.db.yaml up -d
docker compose -f docker-compose.db.yaml ps
# optional: Logs
docker compose -f docker-compose.db.yaml logs -f
```

### 2) Anwendung starten

**Windows (PowerShell):**
```powershell
cd \pfad\zu\relational-databases-orm-java-main
$env:JDBC_URL="jdbc:postgresql://localhost:5432/transferdemo"
$env:JDBC_USERNAME="transferdemo"
$env:JDBC_PASSWORD="transferdemo"
.\mvnw.cmd spring-boot:run -Dspring-boot.run.profiles=local
```

**macOS/Linux (bash/zsh):**
```bash
cd /path/to/relational-databases-orm-java-main
export JDBC_URL=jdbc:postgresql://localhost:5432/transferdemo
export JDBC_USERNAME=transferdemo
export JDBC_PASSWORD=transferdemo
./mvnw spring-boot:run -Dspring-boot.run.profiles=local
```

**Erwartung im Log**:
- Flyway validiert/appliziert Migrationen  
- `Tomcat started on port 8080`  
- `Started TransferdemoApplication ...`

---

## Konfiguration

Die DB-Credentials werden via Umgebungsvariablen gelesen:

- `JDBC_URL` (z. B. `jdbc:postgresql://localhost:5432/transferdemo`)
- `JDBC_USERNAME` (Standard: `transferdemo`)
- `JDBC_PASSWORD` (Standard: `transferdemo`)

Optional Profil `local`:
```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=local
```

---

## Datenbankmigrationen (Flyway)

**Migrationen im Projekt**
- `V2.0__kud_schema.sql` – Tabellen & Constraints
- `V2.1__seed.sql` – Mitglied/Termin/Formular Seed
- `V2.2__seed_teilnahme.sql` – Beispiel-Teilnahme
- `V2.3__indexes.sql` – **neue** Indizes für typische Abfragen/Joins
  ```sql
  CREATE INDEX IF NOT EXISTS idx_termin_datum       ON termin(datum);
  CREATE INDEX IF NOT EXISTS idx_teilnahme_termin   ON teilnahme(termin_id);
  CREATE INDEX IF NOT EXISTS idx_teilnahme_mitglied ON teilnahme(mitglied_id);
  CREATE INDEX IF NOT EXISTS idx_formular_mitglied  ON formular(mitglied_id);
  ```
- `V2.4__fk_rules.sql` – **neue** FK-Löschregeln auf `teilnahme`:
  - `mitglied_id` → **ON DELETE CASCADE**
  - `termin_id` → **ON DELETE CASCADE**
  - `formular_id` → **ON DELETE SET NULL**

**Reset der lokalen DB** (setzt alles zurück!):
```bash
docker compose -f docker-compose.db.yaml down -v
docker compose -f docker-compose.db.yaml up -d
```

**Tabellen ansehen (psql im Container):**
```bash
docker ps
docker exec -it <db-container> psql -U transferdemo -d transferdemo
\dt
SELECT * FROM mitglied;
```

---

## REST API

### Termine

**POST /api/termine** – Termin anlegen  
Request (JSON):
```json
{
  "datum": "2025-09-15",
  "uhrzeit": "19:00:00",
  "ort": "Turnhalle Bern",
  "ferienFlag": false
}
```
Response (201, JSON):
```json
{
  "id": 1,
  "datum": "2025-09-15",
  "uhrzeit": "19:00:00",
  "ort": "Turnhalle Bern",
  "ferienFlag": false
}
```

**GET /api/termine/upcoming** – kommende Termine  
Response (200, JSON):
```json
[
  {
    "id": 1,
    "datum": "2025-09-15",
    "uhrzeit": "19:00:00",
    "ort": "Turnhalle Bern",
    "ferienFlag": false
  }
]
```

**POST /api/termine/{terminId}/zusagen** – Teilnahme zusagen  
Request (JSON):
```json
{
  "mitgliedId": 1,
  "formularId": null
}
```
Response (200, Zahl):
```json
1
```

### Teilnahmen

**POST /api/teilnahmen/{id}/absagen** – Teilnahme absagen  
Response (200, Zahl):
```json
1
```

### Formulare

**POST /api/formulare** – Formular anlegen  
Request (JSON, Minimalbeispiel):
```json
{
  "typ": "Anmeldung",
  "ausgabedatum": "2025-09-01",
  "rueckgabedatum": null,
  "status": "AUSSTEHEND",
  "mitglied": { "id": 1 }
}
```
Response (200, Zahl):
```json
1
```

**PUT /api/formulare/{id}/status?status=GEPRUEFT** – Status ändern  
Response: `204 No Content`

> Hinweis: Endpunkte für Mitglieder sind im MVP nicht exponiert; Einfügen via Seed oder SQL.

---

## Testing (PowerShell, Bash, Postman)

### PowerShell (Windows)
```powershell
# Termin anlegen
Invoke-RestMethod -Method POST http://localhost:8080/api/termine `
  -ContentType "application/json" `
  -Body '{ "datum": "2025-09-15", "uhrzeit": "19:00:00", "ort": "Turnhalle Bern", "ferienFlag": false }'

# Termine abrufen
Invoke-RestMethod -Method GET http://localhost:8080/api/termine/upcoming

# Teilnahme zusagen (angenommen 1/1 existiert)
Invoke-RestMethod -Method POST http://localhost:8080/api/termine/1/zusagen `
  -ContentType "application/json" `
  -Body '{ "mitgliedId": 1, "formularId": null }'

# Teilnahme absagen (Teilnahme-ID aus Zusage verwenden, z. B. 1)
Invoke-RestMethod -Method POST http://localhost:8080/api/teilnahmen/1/absagen

# Formularstatus ändern (angenommen Formular 1 existiert)
Invoke-RestMethod -Method PUT "http://localhost:8080/api/formulare/1/status?status=GEPRUEFT"
```

### Bash (macOS/Linux oder Git Bash auf Windows)
```bash
curl -X POST http://localhost:8080/api/termine   -H "Content-Type: application/json"   -d '{ "datum": "2025-09-15", "uhrzeit": "19:00:00", "ort": "Turnhalle Bern", "ferienFlag": false }'

curl http://localhost:8080/api/termine/upcoming

curl -X POST http://localhost:8080/api/termine/1/zusagen   -H "Content-Type: application/json"   -d '{ "mitgliedId": 1, "formularId": null }'

curl -X POST http://localhost:8080/api/teilnahmen/1/absagen

curl -X PUT "http://localhost:8080/api/formulare/1/status?status=GEPRUEFT"
```

### Postman
- **POST** `http://localhost:8080/api/termine` → Body: raw JSON (siehe oben)  
- **GET** `http://localhost:8080/api/termine/upcoming`  
- **POST** `http://localhost:8080/api/termine/1/zusagen` → Body: raw JSON  
- **POST** `http://localhost:8080/api/teilnahmen/1/absagen`  
- **PUT** `http://localhost:8080/api/formulare/1/status?status=GEPRUEFT`

---

## Troubleshooting

- **Windows: Zugriff auf \\.\pipe\docker_engine verweigert**  
  PowerShell **als Administrator**:
  ```powershell
  Add-LocalGroupMember -Group "docker-users" -Member $env:USERNAME
  # ab- und wieder anmelden
  ```

- **Port 5432 belegt**  
  Andere Postgres-Instanz stoppen oder Port im `docker-compose.db.yaml` anpassen.

- **Flyway hat nichts migriert**  
  Datei heisst strikt `V<Nummer>__<Name>.sql` (zwei Unterstriche) und liegt in  
  `src/main/resources/db/migration/`. App-Logs pruefen.

- **409 Conflict bei Zusage**  
  Bedeutet meist: Teilnahme fuer (mitglied, termin) existiert bereits 
  (DB-Constraint `UNIQUE (mitglied_id, termin_id)` oder Logik). Das ist korrektes Verhalten.

- **Lombok Annotations rot in VS Code**  
  Extension **“Lombok Annotations Support for VS Code”** installieren und VS Code neu starten.

---

## Roadmap

- **Validation & Fehlerantworten** (Bean-Validation-Meldungen, ProblemDetails)  
- **DTO/Mappers** (MapStruct fuer Formular/Teilnahme)  
- **Security (RBAC)** mit Spring Security (Trainer/Admin-Routen)  
- **Tests**: Unit- & Integrationstests (Testcontainers)  
- **Benachrichtigungen**: Erinnerungen vor Terminen/Fristen  
- **Frontend**: Thymeleaf oder SPA

---

## Lizenz & Dank

- Dieses Projekt entstand im Rahmen einer **Projektarbeit an der HFTM**.  
- Basis: ein Spring-Boot Lernprojekt (ORM, JPA, Flyway, Docker).  
- © 2025 – Autor: Milos Stanojevic
