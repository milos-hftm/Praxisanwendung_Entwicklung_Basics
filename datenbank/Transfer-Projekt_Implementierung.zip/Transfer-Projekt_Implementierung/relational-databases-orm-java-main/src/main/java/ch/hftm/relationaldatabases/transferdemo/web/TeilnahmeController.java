package ch.hftm.relationaldatabases.transferdemo.kud.web;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ch.hftm.relationaldatabases.transferdemo.kud.services.TerminService;

/**
 * Endpunkte rund um Teilnahmen.
 * Stellt den fehlenden "Absagen"-Use-Case bereit.
 *
 * POST /api/teilnahmen/{id}/absagen
 *  -> setzt den Status einer bestehenden Teilnahme auf "ABGESAGT"
 *  -> Antwort: ID der betroffenen Teilnahme
 */
@RestController
@RequestMapping("/api/teilnahmen")
public class TeilnahmeController {

    private final TerminService service;

    public TeilnahmeController(TerminService service) {
        this.service = service;
    }

    @PostMapping("/{id}/absagen")
    public ResponseEntity<Long> absagen(@PathVariable Long id) {
        var teilnahme = service.absagen(id);
        return ResponseEntity.ok(teilnahme.getId());
    }
}
