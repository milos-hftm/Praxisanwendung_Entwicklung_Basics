package ch.hftm.relationaldatabases.transferdemo.kud.domain;

public enum Rolle {
    MITGLIED,
    TRAINER,
    ADMIN
}
